# Objective
1. Expand scan configs to support per-source scanning (Gmail only, Slack only, or both) at each scheduled time
2. Add two new default scan times: 2:00 PM and 8:00 PM
3. Build the Slack scanning backend (requires `SLACK_BOT_TOKEN` env secret)
4. Fix light mode color visibility for filter buttons and stat card badges — make hues darker/more saturated in light mode only, keep dark mode untouched
5. Update project documentation

# Tasks

### T001: Schema — Add source fields to scan_configs
- **Blocked By**: []
- **Details**:
  - Add `scanGmail` boolean (default true) and `scanSlack` boolean (default true) to `scan_configs` table
  - This lets each scan time independently control whether to scan Gmail, Slack, or both
  - Update insert schema and types
  - Apply to DB via SQL
  - Files: `shared/schema.ts`
  - Acceptance: Schema compiles, new fields exist in DB

### T002: Storage & Routes — Update scan config CRUD for new fields
- **Blocked By**: [T001]
- **Details**:
  - Update scan config CRUD to accept/return `scanGmail` and `scanSlack` fields
  - Update demo seed to include 5 default scan times: 10:00 AM, 2:00 PM, 6:25 PM, 8:00 PM, 9:55 PM
  - Files: `server/routes.ts`, `server/auth.ts`
  - Acceptance: API returns new fields, demo seeds 5 scan times

### T003: Settings UI — Source toggles per scan time
- **Blocked By**: [T002]
- **Details**:
  - Update Settings page scan config section to show two toggle switches per scan time row: "Gmail" and "Slack"
  - Each toggle independently enables/disables that source for that scan time
  - Add 2:00 PM and 8:00 PM to the quick-add presets
  - Files: `client/src/pages/settings.tsx`
  - Acceptance: Each scan time row shows Gmail/Slack toggles, toggling them sends PATCH with correct fields

### T004: Slack Scanning Backend
- **Blocked By**: [T002]
- **Details**:
  - Create `server/slack-scanner.ts` with function to scan configured Slack channels and DMs
  - Uses `SLACK_BOT_TOKEN` env secret to call Slack Web API (`conversations.history`, `conversations.list`, `users.info`)
  - Searches messages from the last 24 hours for attendance-related keywords
  - Processes through same AI categorization as Gmail
  - Creates attendance records with source="slack" and appropriate Slack metadata
  - Matches sender to students in the roster
  - Creates alerts for urgent messages
  - Gracefully handles missing SLACK_BOT_TOKEN (logs warning, skips scan)
  - Files: `server/slack-scanner.ts`
  - Acceptance: Function can scan Slack channels and create records when token is available

### T005: Scheduler — Integrate Slack scanning
- **Blocked By**: [T004]
- **Details**:
  - Update scheduler to check `scanGmail` and `scanSlack` flags on each scan config
  - When `scanGmail` is true, run Gmail scan (existing behavior)
  - When `scanSlack` is true, run Slack scan (new)
  - Log which sources were scanned at each time
  - Files: `server/scheduler.ts`
  - Acceptance: Scheduler respects per-source flags and runs appropriate scans

### T006: Light Mode Color & Text Fix — ALL buttons, badges, and base text
- **Blocked By**: []
- **Details**:
  - **Base text color**: Change the default/standard font color in light mode from washed-out gray to a deep space-themed dark color (deep navy/indigo like `slate-900` or a dark violet-black) for readability while keeping the space vibe. Dark mode text stays as-is.
  - **ALL filter buttons and stat card/badge colors**: Make every single color darker and more saturated in light mode — not just yellow and gray, ALL of them (rose, orange, amber, slate, blue, green, violet, sky, emerald)
  - Yellow (Personal) and gray (Unexcused/None) are the worst, but all colors wash out on a white background
  - Solution: Use `dark:` variant classes to preserve current dark mode colors exactly as-is, and set darker/more saturated base colors for light mode
  - Apply everywhere colors appear:
    - index.css / global styles: base foreground/text color for light mode
    - dashboard.tsx: all attendance type filter buttons (All, Absent, Late/Tardy, Unexcused), source filter buttons (Gmail, Slack), stat card categoryConfig (icon colors, bg/border classes)
    - records-table.tsx: categoryBadgeColors (Sick/Medical, Personal, Program Event, Technical Issue, Other, None), typeBadgeColors (Absent, Late/Tardy, Unexcused)
  - Dark mode colors and text must remain exactly as they are now — zero changes to dark mode
  - Files: `client/src/index.css`, `client/src/pages/dashboard.tsx`, `client/src/components/records-table.tsx`
  - Acceptance: Base text and every button/badge clearly readable in both light and dark mode

### T007: Update Project Documentation
- **Blocked By**: [T001, T002, T003, T004, T005, T006]
- **Details**:
  - Update `replit.md` with scan source fields, Slack scanner, new default times
  - Update `docs/PROJECT_DOCUMENTATION.md` with new features
  - Files: `replit.md`, `docs/PROJECT_DOCUMENTATION.md`
  - Acceptance: Docs reflect current state

# What the User Needs to Provide
- **SLACK_BOT_TOKEN**: A Slack Bot User OAuth Token from a Slack app installed in the Pursuit workspace. The app needs these scopes: `channels:history`, `groups:history`, `im:history`, `channels:read`, `users:read`, `users:read.email`, `chat:write`. The user or a workspace admin creates the app at api.slack.com/apps, adds the scopes, installs to workspace, and provides the token.
